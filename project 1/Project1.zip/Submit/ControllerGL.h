//
// Created by 吴小宁 on 2019/10/4.
//

#ifndef PROJECT1_CONTROLLERGL_H
#define PROJECT1_CONTROLLERGL_H


class ControllerGL {

};


#endif //PROJECT1_CONTROLLERGL_H
