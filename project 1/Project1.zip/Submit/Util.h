//
// Created by 吴小宁 on 2019/10/6.
//

#ifndef PROJECT1_UTIL_H
#define PROJECT1_UTIL_H

#include <vector>
#include <string>
using namespace std;

class Util {
public:
    static vector<string> split(const string& str, const string& delim);
};


#endif //PROJECT1_UTIL_H
